############################################################################
############################################################################
#Importation de librairies externes
from time import perf_counter

############################################################################
############################################################################
#Definition de fonctions
def initEchequier(val):
    # Initialisation du tableau d'echecs
    e = []
    for i in range(LONGUEUR):
        e.append([val] * LARGEUR)
    
    return e

# Fonction pour verifier si un mouvement est valide
def verif(x, y):
    if (x >= 0 and y >= 0 and x < LONGUEUR and y < LARGEUR and echequier[x][y] == 0):
        return True

# Fonction pour resoudre le probleme des cavaliers
def problemeCavalier(x, y, case):
    # Mettre le cavalier sur la case de depart
    echequier[x][y] = case

    # Si le cavalier a effectue tous les mouvements possibles, le probleme est resolu
    if case == LONGUEUR*LARGEUR:
        x - posX
        y - posY
        return True

    # Essayer tous les mouvements possibles pour le cavalier
    for dx, dy in MOUVEMENTCAVALIER:
        #calcul des nouvelles coordonnees du cavalier
        next_x = x + dx  
        next_y = y + dy
        if verif(next_x, next_y):
            # Si le mouvement est valide, recursivement effectuer le prochain mouvement
            if problemeCavalier(next_x, next_y, case + 1):
                return True

    # Si aucun mouvement valide n'est possible, annuler le mouvement precedent et retourner False
    echequier[x][y] = NON_VISITE
    return False

def afficherTableau(e):
    ligne = ""
    for i in e:
        for j in i:
            if len(str(j)) == 1:
                ligne += str(j) + "   "
            else:
                ligne += str(j) + "  "
        print(ligne)
        ligne = ""

def initTabX():
    #Creation d'un tableau ayant des valeurs allant de 1 a LONGUEUR
    #Ayant LONGUEUR elements
    tab = []
    for i in range(LONGUEUR):
        tab.append(LONGUEUR-i)
    
    return tab

def chercherValeur(tab, val):

    for i, ligne in enumerate(tab): #indice + la ligne actuelle
        for j, elem in enumerate(ligne): #indice + element de la ligne actuelle
            #Si on trouve la valeur souhaitee on retourne les indices (coordonnee)
            if elem == val: 
                return (i, j)

def tabToGraphe(e):

    tabX = initTabX() #Tableau ayant des valeurs allant de 1 a LONGUEUR (axe des oordonnees)
    tabY = ['A','B','C','D','E','F','G','H'] #(axe des abscisses)

    #Affichage du tableau sous forme d'un graphe avec un couple coordonnee actuelle, coordonnee suivante
    for i in range(1,(LONGUEUR*LARGEUR-1)): #Pour chaque cases
        x1,y1 = chercherValeur(e, i) #Cherche la valeur i sur la ligne actuelle pour avoir les indices ou cette valeur se trouve
        x2, y2 = chercherValeur(e, i+1) #Idem pour les prochaines coordonnees du cavalier
        print("{}{} : {}{}".format(tabY[y1],tabX[x1],tabY[y2],tabX[x2])) #Affichage
############################################################################
############################################################################
#Definition des constantes

#taille de l'echequier
LONGUEUR = 8
LARGEUR = 8
NON_VISITE = 0 #case non visitee

# Liste des mouvements possibles pour un cavalier
MOUVEMENTCAVALIER = [(-2,-1), (-2,1), (-1,-2), (-1,2), (1,-2), (1,2), (2,-1), (2,1)]

#Definition des variables
posX = 0
posY = 0

#Programme principal

t1 = perf_counter()
echequier = initEchequier(NON_VISITE)
# Appel de la fonction pour resoudre le probleme des cavaliers a partir de la case (0,0), a l'etape 1
problemeCavalier(posX, posY, 1)


if (echequier == initEchequier(NON_VISITE)): #Si on a pas reussi a trouver de chemin
    print("Il y a aucune solution")
else:
    afficherTableau(echequier)
    tabToGraphe(echequier)
t2 = perf_counter()

print("Le programme s'execute en ",t2-t1,"s")